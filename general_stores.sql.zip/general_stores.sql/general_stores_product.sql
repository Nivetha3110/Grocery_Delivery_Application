-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: general_stores
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `code` varchar(5) NOT NULL,
  `create_date` datetime NOT NULL,
  `description` varchar(1000) NOT NULL,
  `image` longtext,
  `mrp_price` double NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_h3w5r1mx6d0e5c6um32dgyjej` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,_binary '','P01','2020-05-15 02:58:36','Chana Dal 1Kg','/resources/JTurDal1kgPRMING65XX50717_1_P.jpg',105,'Chana Dal 1Kg',99),(2,_binary '','P02','2020-05-15 02:59:56','Moong Dal 1kg','/resources/JMoongDal1kgPRMING58XX50717_1_P.jpg',168,'Moong Dal 1kg',160),(3,_binary '','P03','2020-05-15 03:02:21','Premium Toor Dal 1kg','/resources/JTurDal1kgPRMING65XX50717_1_P.jpg',125,'Premium Toor Dal 1kg',120),(4,_binary '','P04','2020-05-15 03:03:41','Premium Urad Dal 1kg','/resources/JUradDal500gmPRMING72XX50717_1_P.jpg',165,'Urad Dal 1kg',160),(5,_binary '','P05','2020-05-15 03:05:06','Best Quality Masoor Dal 500gm','/resources/JMasoorDal1kgPRMING55XX50717_1_P.jpg',72,'Masoor Dal 500gm',65),(6,_binary '','P06','2020-05-15 03:12:16','Premium Quality Singdana','/resources/images.jpg',165,'Singdana(Groundnut) 1kg',160),(7,_binary '','P07','2020-05-15 03:13:44','Premium Quality singdana','/resources/images.jpg',75,'Singdana(Groundnut) 500gm',70),(8,_binary '','P08','2020-05-29 01:01:54','Kabuli Chana 500gm','/resources/download.jpg',75,'Kabuli Chana 500gm',70),(9,_binary '','P09','2020-07-25 19:42:35','Green Moong Dal 500gm','/resources\\Green Moong.jpg',100,'Green Moong Dal',95),(10,_binary '','P10','2020-07-25 19:43:27','Sabudana 1kg','/resources\\Webp.net-resizeimage (4).jpg',150,'Sabudana ',142),(11,_binary '','P11','2020-07-25 20:04:32','Rajma 1kg','/resources\\Webp.net-resizeimage.jpg',200,'Rajma',190);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-21 12:12:30
